# Introduction to Python Workshop

Welcome to the Macquarie University - Software Carpentry, Introduction to Python Workshop.

In this repository you will find all the workshop materials for the Python component of the workshop, for use in cloudstor's SWAN environment.
